package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/*
 * This is Item page
 */
public class ItemPage 
{	
	 WebDriver driver;
	 
	 //Constructor that will be automatically called as soon as the object of the class is created
	 public ItemPage(WebDriver driver) 
	 {
		 this.driver=driver;
	 }
	 
	 //Locator for first result item
	 By firstResultItem1 = By.id("newBuyBoxPrice");
	 By firstResultItem2 = By.xpath("//span[@id='price']");
	 
	 //Locator for add to cart button
	 By addToCartbtn = By.id("add-to-cart-button");
	 
	 //Method to get first result item element
	 public WebElement getFirstResultItem() 
	 {	
		//The control is dynamically getting changed with two locators 
		try
		{				
			return driver.findElement(firstResultItem1);
		}
		catch(Exception ex)
		{
			return driver.findElement(firstResultItem2);
		}	
	 }
	 
	 //Method to get add to cart button element
	 public WebElement getAddtoCartBtn() 
	 {
		 return driver.findElement(addToCartbtn);
	 }
	 
	 //Method to get the item price
	 public String getFirstElementItemPrice() 
	 { 
		String ItemPrice="";
		WebElement priceOnCart=null;
		priceOnCart = getFirstResultItem();	
		if(priceOnCart != null)
		{
			ItemPrice = priceOnCart.getText();
		}
		return ItemPrice;
	 }	 
	 
	 //Click the Item to the cart
	 public void ClickItemtoCart()
	 {
		 try
		 {
			 WebElement btnAddToCart = getAddtoCartBtn();
			 btnAddToCart.click();
		 }
		 catch(Exception ex)
		 {
			 System.out.println("Problem araised while adding the item to cart"); 
		 }	
	 }
}
