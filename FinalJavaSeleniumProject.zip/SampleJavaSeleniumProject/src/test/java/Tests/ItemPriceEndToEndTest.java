package Tests;
import org.testng.annotations.Test;
import pages.*;
import static org.testng.Assert.assertEquals;

/*
 * Class for all TestNG tests
 */

public class ItemPriceEndToEndTest extends TestBaseSetup
{
	   
	@Test
	public void verifyItemPriceFromLandPagetoCheckoutPage() 
	{
		 //Initializing the variables
		 String searchKey="qa testing for beginners";
		 String firstItempriceFromResultsPage="";
		 String firstItempriceFromItemPage="";
		 String firstItempriceFromCartPage="";		 
		 
		try
		{
			 //Opening the amazon URL
			 driver.get("http://www.amazon.com");
			 
			//Mazimize current window
			 driver.manage().window().maximize();
			 
			 //Creating object of landing page
			 LandingPage home = new LandingPage(driver);
			 //Entering the search key word
			 home.EnterSearchItem(searchKey);
			 //Click the search button 
			 home.ClickSearchButton();
			 
			 //Creating object of search results page
			 SearchResultsPage searchResultsPg = new SearchResultsPage(driver);
			 //Getting the item price from the search results page
			 firstItempriceFromResultsPage = searchResultsPg.getFirstElementItemPrice();	
			 //Clicking the first item
			 searchResultsPg.ClickFirstItem();
			 
			 //Creating object of item page to add the first item to cart and verify the item price
			 ItemPage itemPage = new ItemPage(driver);
			 firstItempriceFromItemPage = itemPage.getFirstElementItemPrice();
			 assertEquals(firstItempriceFromItemPage, firstItempriceFromResultsPage);
			 itemPage.ClickItemtoCart();
			 
			 //Creating object of cart page to proceed checkout and verify the item price
			 CartPage cartPg = new CartPage(driver);
			 firstItempriceFromCartPage = cartPg.gettheFirstItemPriceOnCartPage();	
			 cartPg.ClickProceedToChecoutButton(); 
			 assertEquals(firstItempriceFromCartPage.replace(" ", ""), firstItempriceFromResultsPage);			 
		}
		catch(Exception ex)
		 {
			 //Log the error
			 System.out.println("Error: "+ex.getMessage());
		 }
		 finally
		 {
			 //
		 }
	}	
}
