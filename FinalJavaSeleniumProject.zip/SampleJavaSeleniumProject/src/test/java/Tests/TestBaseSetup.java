package Tests;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

/*
 * This is base class for all tests to create a webdriver based on the browser type we pass in tentg.xml file
 */
public class TestBaseSetup {
	
	public WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}
	
	//Based on the browser type, it will invoke the webdriver
	public void setDriver(String browserType) 
	{
		if (browserType.equals("chrome")) 
		{
			 String chromeDriverPath = System.getProperty("user.dir")+"\\chromedriver.exe";			 
			 //Setting chrome driver path			 
			 System.setProperty("webdriver.chrome.driver",chromeDriverPath);
			 driver = new ChromeDriver();
		}
		else if (browserType.equals("firefox")) 
		{
			String firefoxDriverPath = System.getProperty("user.dir")+"\\geckodriver.exe";			 
			 //Setting chrome driver path			 
			 System.setProperty("webdriver.gecko.driver",firefoxDriverPath);
			 driver = new FirefoxDriver();
		}
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
	}
	
	@Parameters({ "browserType" })
	@BeforeClass
	public void initializeTestBaseSetup(String browserType) 
	{
		//Retrieves the browserType parameter from testng.xml file
		try {
			setDriver(browserType);
			//System.out.println("This is: " + browserType);
		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
	}
	
	@AfterClass
	public void tearDown() 
	{
		//Close the driver session
		if(driver != null)
		{
			driver.quit();
		}
	}
}
