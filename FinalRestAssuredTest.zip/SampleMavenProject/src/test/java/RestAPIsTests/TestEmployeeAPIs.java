package RestAPIsTests;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static org.testng.Assert.assertEquals;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/*This class is to test POST,GET and DELETE operations of Employee APIs
 * Base URL: http://dummy.restapiexample.com
 * POST URL: http://dummy.restapiexample.com/api/v1/create
 * GET URL: http://dummy.restapiexample.com/api/v1/employee/"+employeeID
 * DELETE URL: http://dummy.restapiexample.com/api/v1/delete/"+employeeID
 */
public class TestEmployeeAPIs 
{	
	//Employee ID for get and delete operations
	String employeeID="";
	//Base URL
	String baseURI= "http://dummy.restapiexample.com/api/";
	//Resource paths for each operation
	String postPath="v1/create";
	String getPath="v1/employee/";
	String deletePath="v1/delete/";
	
	//Get the request response for given URL
	public Response GetRequest(String requestURL)
	{
		RequestSpecification employeeRequest;
		Response getResPonse=null;
		try
		{
			employeeRequest= RestAssured.given();
			getResPonse= employeeRequest.get(requestURL);
		}
		catch(Exception ex)
		{
			//Log the exception
			System.out.println("Error:"+ex.getMessage());
		}
		finally
		{
			//
		}
		return getResPonse;
	}
	
	//post the request with the given URL
	public Response PostRequest(String postURL,String requestBody)
	{
		RequestSpecification employeeRequest;
		Response postReponse=null;
		try
		{
			employeeRequest= RestAssured.given();			
			//Add the header to post request
			employeeRequest.header("Content-Type","application/json");
			//Set the body string
			employeeRequest.body(requestBody);
			postReponse= employeeRequest.post(postURL);
		}
		catch(Exception ex)
		{
			//Log the exception
			System.out.println("Error:"+ex.getMessage());
		}
		finally
		{
			//
		}
		return postReponse;
	}
	
	//Delete the request using given URL
	public Response DeleteRequest(String requestURL)
	{
		RequestSpecification employeeRequest;
		Response delResPonse=null;
		try
		{
			employeeRequest= RestAssured.given();
			delResPonse= employeeRequest.delete(requestURL);
		}
		catch(Exception ex)
		{
			//Log the exception
			System.out.println("Error:"+ex.getMessage());
		}
		finally
		{
			//
		}
		return delResPonse;
	}
	
	///Post the sample employee request and store the employeeID to be used for get and delete operations
	@BeforeClass
	public void initializeTestBaseSetup() 
	{
		Response postReponse=null;
		JsonPath jp1=null;
		String requestURL = baseURI+postPath;
		//Retrieves the browserType parameter from testng.xml file
		try {
			//Generating sample body content
			String requestBody = "{\"employee_name\": \"Anugam\",\"employee_salary\": 85600,\"employee_age\": 48,\"profile_image\": \"\"}";	
			postReponse = PostRequest(requestURL, requestBody);
			//If post is successful
			if (postReponse.getStatusCode() == 200)
			{
				//Converting response to json path object
				jp1 = new JsonPath(postReponse.asString());
				//Logic: To get the Employee ID which is created above with POST method using string methods		
				int idIndex = jp1.get("data").toString().indexOf("id");
				int strlen = jp1.get("data").toString().length();
				employeeID = jp1.get("data").toString().substring(idIndex+3,strlen-1);
			}			
		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
	}
	
	@AfterClass
	public void tearDown() 
	{
		//
	}
	
	@Test
	public void VerifyGetEmployeeAPIForStatusCode() 
	{	 
		Response getResPonse=null;
		//String getSpecificEmployeesURL ="http://dummy.restapiexample.com/api/v1/employee/"+employeeID;	
		String requestURL = baseURI+getPath+employeeID;
		try
		{
			//Testing the GET method with given employeeID(Which is created in above post method)				
			getResPonse= GetRequest(requestURL);	
			//Verifying the response status code.It should be 200 for successful for get operation
			assertEquals(getResPonse.getStatusCode(),200);
		}
		catch(Exception ex)
		{
			 //Log the error
			System.out.println("Error: "+ex.getMessage());
		}
		finally
		{
			 //
		}
	}
	
	@Test
	public void VerifyDeleteEmployeeAPIForStatusCodeAndMessage() 
	{	 
		Response delResPonse=null;
		//String deleteSpecificEmployeesURL ="http://dummy.restapiexample.com/api/v1/delete/"+employeeID;	
		String requestURL = baseURI+deletePath+employeeID;
		try
		{
			//Testing the DELETE method with given employeeID(Which is created in above post method)				
			delResPonse= DeleteRequest(requestURL);	
			//Verifying the response status code.It should be 200 for successful for delete operation
			assertEquals(delResPonse.getStatusCode(),200);
			//Verifying the response message for DELETE operation
			assertEquals(delResPonse.jsonPath().get("message"),"Successfully! Record has been deleted");	
		}
		catch(Exception ex)
		{
			 //Log the error
			System.out.println("Error: "+ex.getMessage());
		}
		finally
		{
			 //
		}
	}
}
